package com.example.galaxybio.mobile

import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.WearableListenerService

/** Receives "type|value|timeMs" messages sent by the watch app on path /bio. */
class WearReceiver : WearableListenerService() {
    override fun onMessageReceived(event: MessageEvent) {
        if (event.path != "/bio") return
        val parts = String(event.data, Charsets.UTF_8).split("|", limit = 3)
        if (parts.size < 3) return
        val time = parts[2].toLongOrNull() ?: System.currentTimeMillis()
        BioStore.add(applicationContext, Reading(parts[0], parts[1], time))
    }
}
