package com.example.galaxybio.mobile

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Reading(val type: String, val value: String, val timeMs: Long)

data class PhoneState(
    val heartRate: String = "--",
    val heartRateTime: Long = 0L,
    val spo2: String = "--",
    val ecg: String = "--",
    val recent: List<Reading> = emptyList()
)

/** Holds the latest readings in memory and appends every one to readings.csv on the phone. */
object BioStore {
    private val _state = MutableStateFlow(PhoneState())
    val state: StateFlow<PhoneState> = _state.asStateFlow()

    private val fmt get() = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    fun add(context: Context, r: Reading) {
        _state.update { s ->
            val recent = (listOf(r) + s.recent).take(40)
            when (r.type) {
                "HR" -> s.copy(heartRate = r.value, heartRateTime = r.timeMs, recent = recent)
                "SpO2" -> s.copy(spo2 = r.value, recent = recent)
                "ECG" -> s.copy(ecg = r.value, recent = recent)
                else -> s.copy(recent = recent)
            }
        }
        runCatching {
            val f = file(context)
            if (!f.exists()) f.writeText("time,type,value\n")
            f.appendText("${fmt.format(Date(r.timeMs))},${r.type},${r.value}\n")
        }
    }

    fun file(context: Context) = File(context.filesDir, "readings.csv")

    /** Last [maxLines] rows of the log, for sharing. */
    fun exportText(context: Context, maxLines: Int = 500): String {
        val f = file(context)
        if (!f.exists()) return ""
        val lines = f.readLines()
        return (listOf(lines.first()) + lines.drop(1).takeLast(maxLines)).joinToString("\n")
    }
}
