package com.example.galaxybio.mobile

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()
            ) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    PhoneScreen()
                }
            }
        }
    }
}

private val clock = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

@Composable
private fun PhoneScreen() {
    val state by BioStore.state.collectAsState()
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Heart rate", style = MaterialTheme.typography.labelLarge)
                    Text("${state.heartRate} bpm", fontSize = 48.sp)
                    Text(
                        text = if (state.heartRateTime == 0L) "Waiting for the watch..."
                        else "Updated ${clock.format(Date(state.heartRateTime))}",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Card(modifier = Modifier.weight(1f)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("SpO2", style = MaterialTheme.typography.labelLarge)
                        Text(state.spo2, fontSize = 28.sp)
                    }
                }
                Card(modifier = Modifier.weight(1f)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("ECG", style = MaterialTheme.typography.labelLarge)
                        Text(state.ecg, fontSize = 16.sp)
                    }
                }
            }
        }
        item {
            Button(onClick = { shareLog(context) }, modifier = Modifier.fillMaxWidth()) {
                Text("Share log (CSV text)")
            }
        }
        item {
            Text("Recent readings", style = MaterialTheme.typography.titleMedium)
        }
        items(state.recent) { r ->
            Text("${clock.format(Date(r.timeMs))}   ${r.type}   ${r.value}")
        }
        if (state.recent.isEmpty()) {
            item {
                Text(
                    "Open Galaxy Bio on the watch and tap Heart rate, SpO2 or ECG. " +
                        "Readings appear here while the watch is connected to this phone.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

private fun shareLog(context: Context) {
    val text = BioStore.exportText(context)
    if (text.isBlank()) return
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, "Galaxy Bio readings")
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(Intent.createChooser(send, "Share log").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}
