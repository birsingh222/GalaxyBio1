package com.example.galaxybio

import android.content.Context
import androidx.health.services.client.HealthServices
import androidx.health.services.client.MeasureCallback
import androidx.health.services.client.data.Availability
import androidx.health.services.client.data.DataPointContainer
import androidx.health.services.client.data.DataType
import androidx.health.services.client.data.DeltaDataType

/** Live heart rate through Google's Health Services (works on any Wear OS watch, no Samsung SDK). */
class HeartRateSource(context: Context) {
    private val client = HealthServices.getClient(context.applicationContext).measureClient
    private var callback: MeasureCallback? = null

    val running: Boolean get() = callback != null

    fun start(onBpm: (Int) -> Unit, onAvailability: (String) -> Unit) {
        if (callback != null) return
        val cb = object : MeasureCallback {
            override fun onAvailabilityChanged(
                dataType: DeltaDataType<*, *>,
                availability: Availability
            ) {
                onAvailability(availability.toString())
            }

            override fun onDataReceived(data: DataPointContainer) {
                data.getData(DataType.HEART_RATE_BPM).lastOrNull()?.let {
                    onBpm(it.value.toInt())
                }
            }
        }
        callback = cb
        client.registerMeasureCallback(DataType.HEART_RATE_BPM, cb)
    }

    fun stop() {
        callback?.let { client.unregisterMeasureCallbackAsync(DataType.HEART_RATE_BPM, it) }
        callback = null
    }
}
