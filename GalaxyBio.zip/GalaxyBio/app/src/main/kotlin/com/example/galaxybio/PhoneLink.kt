package com.example.galaxybio

import android.content.Context
import com.google.android.gms.wearable.Wearable

/**
 * Sends each reading to the paired Android phone over the Wear OS Data Layer.
 * If no phone is connected the message is simply dropped; the watch keeps working alone.
 * Payload format (UTF-8): type|value|timeMs
 */
class PhoneLink(context: Context) {
    private val nodes = Wearable.getNodeClient(context.applicationContext)
    private val messages = Wearable.getMessageClient(context.applicationContext)

    fun send(r: Reading) {
        val bytes = "${r.type}|${r.value}|${r.timeMs}".toByteArray(Charsets.UTF_8)
        nodes.connectedNodes.addOnSuccessListener { list ->
            list.forEach { node -> messages.sendMessage(node.id, PATH, bytes) }
        }
    }

    companion object {
        const val PATH = "/bio"
    }
}
