package com.example.galaxybio

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Reading(
    val type: String,
    val value: String,
    val timeMs: Long = System.currentTimeMillis()
)

/** Appends every reading to readings.csv inside the app's private storage on the watch. */
object ReadingLog {
    private val fmt get() = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    fun file(context: Context) = File(context.filesDir, "readings.csv")

    fun append(context: Context, r: Reading) {
        val f = file(context)
        if (!f.exists()) f.writeText("time,type,value\n")
        f.appendText("${fmt.format(Date(r.timeMs))},${r.type},${r.value}\n")
    }
}
