package com.example.galaxybio

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

data class UiState(
    val heartRate: Int? = null,
    val heartRateRunning: Boolean = false,
    val heartRateNote: String = "",
    val samsungSupported: Boolean = false,
    val busy: Boolean = false,
    val status: String = "Ready",
    val lastSpo2: String = "--",
    val lastEcg: String = "--"
)

class BioViewModel(app: Application) : AndroidViewModel(app) {
    private val heartRate = HeartRateSource(app)
    private val samsung = SamsungSensors(app)
    private val phone = PhoneLink(app)

    private val _ui = MutableStateFlow(UiState(samsungSupported = samsung.supported))
    val ui: StateFlow<UiState> = _ui

    fun toggleHeartRate() {
        if (heartRate.running) {
            heartRate.stop()
            _ui.update { it.copy(heartRateRunning = false, heartRateNote = "") }
        } else {
            _ui.update { it.copy(heartRateRunning = true, status = "Reading heart rate...") }
            try {
                heartRate.start(
                    onBpm = { bpm ->
                        _ui.update { it.copy(heartRate = bpm) }
                        val r = Reading("HR", bpm.toString())
                        ReadingLog.append(getApplication(), r)
                        phone.send(r)
                    },
                    onAvailability = { note -> _ui.update { it.copy(heartRateNote = note) } }
                )
            } catch (e: Exception) {
                _ui.update { it.copy(heartRateRunning = false, status = "HR error: ${e.message}") }
            }
        }
    }

    fun measureSpo2() {
        if (_ui.value.busy) return
        _ui.update { it.copy(busy = true, status = "Starting SpO2...") }
        samsung.measureSpo2(
            onStatus = { s -> _ui.update { it.copy(status = s, busy = s.isBusyStatus()) } },
            onResult = { r ->
                ReadingLog.append(getApplication(), r)
                phone.send(r)
                _ui.update { it.copy(lastSpo2 = r.value, busy = false, status = "SpO2 done") }
            }
        )
    }

    fun measureEcg() {
        if (_ui.value.busy) return
        _ui.update { it.copy(busy = true, status = "Starting ECG...") }
        samsung.measureEcg(
            onStatus = { s -> _ui.update { it.copy(status = s, busy = s.isBusyStatus()) } },
            onResult = { r ->
                ReadingLog.append(getApplication(), r)
                phone.send(r)
                _ui.update { it.copy(lastEcg = r.value, busy = false, status = "ECG done") }
            }
        )
    }

    fun cancel() {
        samsung.stop()
        _ui.update { it.copy(busy = false, status = "Stopped") }
    }

    // Status lines that start with these mean the measurement already ended.
    private fun String.isBusyStatus() =
        !(startsWith("SpO2 error") || startsWith("ECG error") || startsWith("Samsung") ||
            contains("timed out") || contains("not included"))

    override fun onCleared() {
        heartRate.stop()
        samsung.stop()
    }
}
