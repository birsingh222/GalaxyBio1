package com.example.galaxybio

import android.Manifest
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import androidx.wear.compose.foundation.lazy.ScalingLazyColumn
import androidx.wear.compose.material.Chip
import androidx.wear.compose.material.MaterialTheme
import androidx.wear.compose.material.Text

class MainActivity : ComponentActivity() {
    private val vm: BioViewModel by viewModels()

    private val permissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* buttons just try; sensors report an error if a permission was denied */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        permissions.launch(arrayOf(Manifest.permission.BODY_SENSORS) + SAMSUNG_PERMISSIONS)

        setContent {
            MaterialTheme {
                val ui by vm.ui.collectAsState()
                BioScreen(
                    ui = ui,
                    onHeartRate = vm::toggleHeartRate,
                    onSpo2 = vm::measureSpo2,
                    onEcg = vm::measureEcg,
                    onCancel = vm::cancel
                )
            }
        }
    }
}

@Composable
private fun BioScreen(
    ui: UiState,
    onHeartRate: () -> Unit,
    onSpo2: () -> Unit,
    onEcg: () -> Unit,
    onCancel: () -> Unit
) {
    ScalingLazyColumn(modifier = Modifier.fillMaxWidth()) {
        item {
            Text(
                text = ui.heartRate?.let { "$it bpm" } ?: "-- bpm",
                fontSize = 28.sp,
                textAlign = TextAlign.Center
            )
        }
        item {
            Chip(
                onClick = onHeartRate,
                label = { Text(if (ui.heartRateRunning) "Stop heart rate" else "Heart rate") },
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Chip(
                onClick = onSpo2,
                enabled = ui.samsungSupported && !ui.busy,
                label = { Text("SpO2") },
                secondaryLabel = { Text(ui.lastSpo2) },
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Chip(
                onClick = onEcg,
                enabled = ui.samsungSupported && !ui.busy,
                label = { Text("ECG (30 s)") },
                secondaryLabel = { Text(ui.lastEcg) },
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (ui.busy) {
            item {
                Chip(
                    onClick = onCancel,
                    label = { Text("Cancel") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        item {
            Text(
                text = ui.status,
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
        }
        if (!ui.samsungSupported) {
            item {
                Text(
                    text = "SpO2 and ECG need the Samsung SDK build (see README).",
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}
