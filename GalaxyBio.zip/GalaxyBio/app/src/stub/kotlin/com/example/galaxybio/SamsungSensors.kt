package com.example.galaxybio

import android.content.Context

/** Extra runtime permissions needed by the Samsung SDK (none in the stub build). */
val SAMSUNG_PERMISSIONS: Array<String> = emptyArray()

/** Placeholder used when the Samsung SDK .aar is not present. Heart rate still works. */
class SamsungSensors(@Suppress("UNUSED_PARAMETER") context: Context) {
    val supported = false

    fun measureSpo2(onStatus: (String) -> Unit, onResult: (Reading) -> Unit) {
        onStatus("Samsung SDK not included in this build")
    }

    fun measureEcg(onStatus: (String) -> Unit, onResult: (Reading) -> Unit) {
        onStatus("Samsung SDK not included in this build")
    }

    fun stop() {}
}
