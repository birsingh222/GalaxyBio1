package com.example.galaxybio

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.samsung.android.service.health.tracking.ConnectionListener
import com.samsung.android.service.health.tracking.HealthTracker
import com.samsung.android.service.health.tracking.HealthTrackerException
import com.samsung.android.service.health.tracking.HealthTrackingService
import com.samsung.android.service.health.tracking.data.DataPoint
import com.samsung.android.service.health.tracking.data.HealthTrackerType
import com.samsung.android.service.health.tracking.data.ValueKey
import java.io.File
import kotlin.math.abs

/** Runtime permission the Samsung SDK asks for, on top of BODY_SENSORS. */
val SAMSUNG_PERMISSIONS: Array<String> =
    arrayOf("com.samsung.android.hardware.sensormanager.permission.READ_ADDITIONAL_HEALTH_DATA")

/**
 * SpO2 and ECG through the Samsung Health Sensor SDK (talks to the watch's Health Platform
 * service directly, no Samsung phone involved).
 *
 * NOTE: written against SDK v1.4.x docs, not compiled against the real .aar here.
 * If a constant or signature differs in your SDK version, the compiler will point at the line.
 */
class SamsungSensors(private val context: Context) {
    val supported = true

    private val main = Handler(Looper.getMainLooper())
    private var service: HealthTrackingService? = null
    private var tracker: HealthTracker? = null
    private var timeout: Runnable? = null

    // ---- connection -------------------------------------------------------------------------

    private fun withService(onStatus: (String) -> Unit, block: (HealthTrackingService) -> Unit) {
        service?.let { block(it); return }
        var created: HealthTrackingService? = null
        val listener = object : ConnectionListener {
            override fun onConnectionSuccess() {
                service = created
                created?.let { s -> main.post { block(s) } }
            }

            override fun onConnectionEnded() {
                service = null
            }

            override fun onConnectionFailed(e: HealthTrackerException) {
                main.post {
                    onStatus("Samsung service failed (code ${e.errorCode}). Is developer mode on?")
                }
            }
        }
        created = HealthTrackingService(listener, context.applicationContext)
        created?.connectService()
    }

    // ---- SpO2 -------------------------------------------------------------------------------

    fun measureSpo2(onStatus: (String) -> Unit, onResult: (Reading) -> Unit) {
        withService(onStatus) { svc ->
            stopTracker()
            val t = svc.getHealthTracker(HealthTrackerType.SPO2_ON_DEMAND)
            tracker = t
            onStatus("Hold still, measuring SpO2 (~30 s)")
            t.setEventListener(object : HealthTracker.TrackerEventListener {
                override fun onDataReceived(points: List<DataPoint>) {
                    val p = points.lastOrNull() ?: return
                    val spo2: Int = p.getValue(ValueKey.SpO2Set.SPO2)
                    val status: Int = p.getValue(ValueKey.SpO2Set.STATUS)
                    main.post {
                        if (spo2 > 0) {
                            onResult(Reading("SpO2", "$spo2%"))
                            stop()
                        } else {
                            onStatus("Measuring SpO2... (status $status)")
                        }
                    }
                }

                override fun onError(error: HealthTracker.TrackerError) {
                    main.post { onStatus("SpO2 error: $error") }
                }

                override fun onFlushCompleted() {}
            })
            armTimeout(45_000) { onStatus("SpO2 timed out, try again") }
        }
    }

    // ---- ECG (raw samples, 30 s, finger on the top button) ------------------------------------

    fun measureEcg(onStatus: (String) -> Unit, onResult: (Reading) -> Unit) {
        withService(onStatus) { svc ->
            stopTracker()
            val t = svc.getHealthTracker(HealthTrackerType.ECG_ON_DEMAND)
            tracker = t
            val samples = ArrayList<Float>(16_000)
            var leadOffCount = 0
            val startedAt = System.currentTimeMillis()
            onStatus("Rest a finger on the top button, hold still (30 s)")

            t.setEventListener(object : HealthTracker.TrackerEventListener {
                override fun onDataReceived(points: List<DataPoint>) {
                    for (p in points) {
                        val leadOff: Int = p.getValue(ValueKey.EcgSet.LEAD_OFF)
                        val mv: Float = p.getValue(ValueKey.EcgSet.ECG)
                        samples.add(mv)
                        if (leadOff != 0) leadOffCount++
                    }
                    val secs = (System.currentTimeMillis() - startedAt) / 1000
                    main.post { onStatus("ECG recording... ${secs}s") }
                }

                override fun onError(error: HealthTracker.TrackerError) {
                    main.post { onStatus("ECG error: $error") }
                }

                override fun onFlushCompleted() {}
            })

            armTimeout(30_000) {
                val summary = summarizeEcg(samples, leadOffCount, startedAt)
                stop()
                onResult(Reading("ECG", summary))
            }
        }
    }

    /** Saves raw samples to a CSV and returns a short summary. Not a medical diagnosis. */
    private fun summarizeEcg(samples: List<Float>, leadOff: Int, startedAt: Long): String {
        if (samples.isEmpty()) return "no data"
        File(context.filesDir, "ecg_$startedAt.csv")
            .writeText(samples.joinToString("\n", prefix = "mV\n"))

        val seconds = ((System.currentTimeMillis() - startedAt) / 1000.0).coerceAtLeast(1.0)
        val rate = samples.size / seconds
        val mean = samples.average().toFloat()
        val centered = samples.map { it - mean }
        val peak = centered.maxOf { abs(it) }

        // Very rough beat count: samples above 60% of the peak, at least 0.3 s apart.
        val minGap = (rate * 0.3).toInt().coerceAtLeast(1)
        var beats = 0
        var last = -minGap
        centered.forEachIndexed { i, v ->
            if (v > peak * 0.6f && i - last >= minGap) { beats++; last = i }
        }
        val bpm = (beats * 60.0 / seconds).toInt()
        return "~$bpm bpm, ${samples.size} samples, lead-off $leadOff"
    }

    // ---- housekeeping -----------------------------------------------------------------------

    private fun armTimeout(ms: Long, action: () -> Unit) {
        timeout?.let { main.removeCallbacks(it) }
        val r = Runnable { action() }
        timeout = r
        main.postDelayed(r, ms)
    }

    private fun stopTracker() {
        tracker?.unsetEventListener()
        tracker = null
    }

    fun stop() {
        timeout?.let { main.removeCallbacks(it) }
        timeout = null
        stopTracker()
    }
}
