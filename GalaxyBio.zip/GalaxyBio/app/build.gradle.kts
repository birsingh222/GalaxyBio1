plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.example.galaxybio"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.galaxybio"
        minSdk = 30
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    // "stub"    = builds with no Samsung SDK file. Heart rate only (Google Health Services).
    // "samsung" = needs the Samsung Health Sensor SDK .aar in app/libs. Adds SpO2 + ECG.
    flavorDimensions += "sdk"
    productFlavors {
        create("stub") { dimension = "sdk" }
        create("samsung") { dimension = "sdk" }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")

    implementation("androidx.compose.ui:ui:1.7.5")
    implementation("androidx.wear.compose:compose-material:1.4.0")
    implementation("androidx.wear.compose:compose-foundation:1.4.0")

    implementation("androidx.health:health-services-client:1.0.0")
    implementation("com.google.guava:guava:33.3.1-android")
    implementation("com.google.android.gms:play-services-wearable:18.2.0")

    // Samsung Health Sensor SDK (download it yourself, see README)
    "samsungImplementation"(fileTree(mapOf("dir" to "libs", "include" to listOf("*.aar"))))
}
